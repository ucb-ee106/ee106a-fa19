^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ar_track_alvar_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.1 (2017-06-14)
------------------
* [maintenance] Remove unnecessary metapkg.

0.7.0 (2017-04-21)
------------------
* Consolidate ar_track_alvar* packages into a single repo (`#120 <https://github.com/sniekum/ar_track_alvar/issues/120>`_)
* Contributors: Isaac I.Y. Saito

0.5.2 (2017-04-20)
------------------
* Add CI config. Update maintainer. `#2 <https://github.com/sniekum/ar_track_alvar_msgs/issues/2>`_
* Contributors: Scott Niekum, Isaac I.Y. Saito

0.5.1 (2015-04-12)
------------------
* Release into Jade ROS
* Contributors: Isaac IY Saito

0.5.0 (2014-06-25)
------------------
* migrate from ar_track_alvar repository
* Contributors: Jihoon Lee
